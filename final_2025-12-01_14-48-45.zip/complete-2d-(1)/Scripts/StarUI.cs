using Godot;
using System;

public partial class StarUI : CanvasLayer
{
	private ProgressBar _starBar;

	
	[Export] public int MaxStars { get; set; } = 5;

	public override void _Ready()
	{
		
		_starBar = GetNode<ProgressBar>("StarBar");

		
		_starBar.MaxValue = MaxStars;
		_starBar.Value = 0;
	}

	
	public void UpdateStars(int newCount)
	{
		_starBar.Value = newCount;

		
		GD.Print($"Progress updated: {newCount}/{_starBar.MaxValue}");
	}
}
