using Godot;
using System;

public partial class Enemy2 : CharacterBody2D
{
	[Export] public float Speed { get; set; } = 300.0f;

	[Export] public CharacterBody2D TargetToChase { get; set; }
	private NavigationAgent2D _navigationAgent;

	public override void _Ready()
	{
		_navigationAgent = GetNode<NavigationAgent2D>("NavigationAgent2D");

		// Optional: if you want the agent to start moving right away
		_navigationAgent.TargetPosition = TargetToChase?.GlobalPosition ?? GlobalPosition;
	}

	public override void _PhysicsProcess(double delta)
	{
		if (_navigationAgent == null || TargetToChase == null)
			return;

		// Update the target each frame (so the enemy follows the player)
		_navigationAgent.TargetPosition = TargetToChase.GlobalPosition;

		// Get the next path point from the navigation agent
		if (!_navigationAgent.IsNavigationFinished())
		{
			Vector2 nextPoint = _navigationAgent.GetNextPathPosition();

			// Calculate direction and move
			Vector2 direction = (nextPoint - GlobalPosition).Normalized();
			Velocity = direction * Speed;
			MoveAndSlide();
		}
		else
		{
			// Stop moving if path is finished
			Velocity = Vector2.Zero;
		}
	}
}
