using Godot;
using System;

public partial class Enemy : CharacterBody2D
{
	[Export] public float MovementSpeed { get; set; } = 200.0f;
	[Export] public float DetectionRadius { get; set; } = 300.0f;
	[Export] public NodePath PlayerPath { get; set; }  

	private NavigationAgent2D _navigationAgent;
	private NavigationRegion2D _navRegion;
	private CharacterBody2D _player;
	private RandomNumberGenerator _rng = new RandomNumberGenerator();
	private AnimatedSprite2D _sprite;
	private Area2D _hitbox; 

	public override void _Ready()
	{
		_navigationAgent = GetNode<NavigationAgent2D>("NavigationAgent2D");
		_navRegion = GetNodeOrNull<NavigationRegion2D>("../NavigationRegion2D");

		_sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		_sprite.Play("IDLE"); 

		
		_hitbox = GetNodeOrNull<Area2D>("Area2D");
		if (_hitbox != null)
			_hitbox.BodyEntered += OnBodyEntered;
		else
			GD.PushWarning("Enemy is missing an Area2D child for player collision.");

		
		if (PlayerPath != null && HasNode(PlayerPath))
			_player = GetNode<CharacterBody2D>(PlayerPath);
		else
			_player = GetTree().Root.FindChild("Player", recursive: true, owned: false) as CharacterBody2D;

		_rng.Randomize();
		Callable.From(ActorSetup).CallDeferred();
	}

	public override void _PhysicsProcess(double delta)
	{
		base._PhysicsProcess(delta);

		if (_player != null && IsPlayerInRange())
		{
			_navigationAgent.TargetPosition = _player.GlobalPosition;
		}
		else if (_navigationAgent.IsNavigationFinished())
		{
			SetRandomTargetInsideNavRegion();
		}

		if (_navigationAgent.IsNavigationFinished())
			return;

		Vector2 nextPathPosition = _navigationAgent.GetNextPathPosition();
		Velocity = GlobalPosition.DirectionTo(nextPathPosition) * MovementSpeed;
		MoveAndSlide();
	}

	private bool IsPlayerInRange()
	{
		return GlobalPosition.DistanceTo(_player.GlobalPosition) <= DetectionRadius;
	}

	private async void ActorSetup()
	{
		await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
		SetRandomTargetInsideNavRegion();
	}

	private void SetRandomTargetInsideNavRegion()
	{
		if (_navRegion == null)
			return;

		var navPoly = _navRegion.NavigationPolygon;
		if (navPoly == null)
			return;

		Vector2[] outline = navPoly.GetOutline(0);
		if (outline == null || outline.Length < 3)
			return;

		float minX = outline[0].X, maxX = outline[0].X;
		float minY = outline[0].Y, maxY = outline[0].Y;
		for (int i = 1; i < outline.Length; i++)
		{
			Vector2 p = outline[i];
			if (p.X < minX) minX = p.X;
			if (p.Y < minY) minY = p.Y;
			if (p.X > maxX) maxX = p.X;
			if (p.Y > maxY) maxY = p.Y;
		}

		Rect2 bounds = new Rect2(new Vector2(minX, minY), new Vector2(maxX - minX, maxY - minY));

		Vector2 randomLocal;
		int tries = 0;
		const int maxTries = 60;
		do
		{
			randomLocal = new Vector2(
				_rng.RandfRange(bounds.Position.X, bounds.End.X),
				_rng.RandfRange(bounds.Position.Y, bounds.End.Y)
			);
			tries++;
		}
		while (!Geometry2D.IsPointInPolygon(randomLocal, outline) && tries < maxTries);

		if (tries >= maxTries)
			randomLocal = outline[0];

		Vector2 randomGlobal = _navRegion.ToGlobal(randomLocal);
		Rid map = GetWorld2D().NavigationMap;
		if (!map.IsValid)
			return;

		Vector2 validPoint = NavigationServer2D.MapGetClosestPoint(map, randomGlobal);
		_navigationAgent.TargetPosition = validPoint;
	}

	
	private void OnBodyEntered(Node body)
	{
		if (body is Player)
		{
			GetTree().ChangeSceneToFile("res://Scenes/Lose_menu.tscn");
		}
	}
}
