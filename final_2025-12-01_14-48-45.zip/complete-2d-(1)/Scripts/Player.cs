using Godot;
using System;

public partial class Player : CharacterBody2D
{
	[Export] public float Speed = 200.0f;

	[Signal]
	public delegate void StarCountChangedEventHandler(int newCount);

	private AnimatedSprite2D _animatedSprite;
	private int _starCount = 0;

	public override void _Ready()
	{
		_animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");

		var area = GetNodeOrNull<Area2D>("Area2D");
		if (area != null)
			area.BodyEntered += OnBodyEntered;
	}

	private void _on_star_collected()
	{
		AddStar();
	}

	public void AddStar()
	{
		_starCount++;
		EmitSignal(SignalName.StarCountChanged, _starCount);
	}

	private void OnBodyEntered(Node body)
	{
		if (body is Enemy)
			GetTree().ChangeSceneToFile("res://Lose_menu.tscn");
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Vector2.Zero;

		// --- TOP-DOWN MOVEMENT ---
		float inputX = Input.GetActionStrength("ui_right") - Input.GetActionStrength("ui_left");
		float inputY = Input.GetActionStrength("ui_down") - Input.GetActionStrength("ui_up");

		velocity = new Vector2(inputX, inputY);

		// Prevent faster diagonal movement
		if (velocity.Length() > 1)
			velocity = velocity.Normalized();

		velocity *= Speed;

		Velocity = velocity;
		MoveAndSlide();

		// Animation
		if (velocity.Length() > 5)
			_animatedSprite.Play("walk");
		else
			_animatedSprite.Play("IDLE");

		// Flip sprite left/right
		if (velocity.X != 0)
			_animatedSprite.FlipH = velocity.X < 0;
	}
}
