using Godot;
using System;

public partial class MainMenu : Control
{
	private void _on_button_pressed()
	{
		// Start button pressed
		GetTree().ChangeSceneToFile("res://Scenes/main.tscn");
	}

	private void _on_button_2_pressed()
	{
		// Settings button pressed
		GD.Print("settings");
	}

	private void _on_button_3_pressed()
	{
		// Exit button pressed
		GetTree().Quit();
	}
}
